<footer>
	<p>Copyright &copy; <?php echo date("Y"); echo " "; bloginfo('name'); ?></p>
</footer>
</div> <!-- end outerWrapper -->
<?php wp_footer(); ?>
</body>
</html>